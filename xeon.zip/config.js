//base by DGXeon (Xeon Bot Inc.)
//re-upload? recode? copy code? give credit ya :)
//YouTube: @Team56rj
//Instagram: @rishilegend56
//Telegram: t.me/TEAM56RJ
//GitHub: @Rishi1heart1maker
//WhatsApp: +923252132556
//want more free bot scripts? subscribe to my youtube channel: https://youtube.com/@Team56rj

//contact details
global.ownernomer = "2349118383807"
global.owner = ["2349118383807"]
global.ownername = "🪲Rishi Bug-V12"
global.ytname = "YT: @Team56rj"
global.socialm = "GitHub: Rishi1Heart1Maker"
global.location = "Pakistan, Sindh, Karachi"

global.ownernumber = '2349118383807'  //creator number
global.ownername = '🪲Rishi Bug-V12' //owner name
global.botname = 'ᴿⁱˢʰⁱ ᴮᵘᵍ ᴮᵒᵗ ᵛ¹²' //name of the bot

//sticker details
global.packname = 'Sticker By'
global.author = '🪲Rishi Bug-V12\n\nContact: +2349118383807'

//console view/theme
global.themeemoji = '🪀'
global.wm = "Xeon Bot Inc."

//theme link
global.link = 'https://whatsapp.com/channel/0029VaukQYTBqbqzo25tz72s'

//prefix
global.prefa = ['','!','.',',','🐤','🗿'] 

global.limitawal = {
    premium: "Infinity",
    free: 20
}

//menu type 
//v1 is image menu, 
//v2 is link + image menu,
//v3 is video menu,
//v4 is call end menu
global.typemenu = 'v1'

// Global Respon
global.mess = {
    success: 'Done✓',
    admin: `\`[ # ]\` This Command Can Only Be Used By Group Admins !`,
    botAdmin: `\`[ # ]\` This Command Can Only Be Used When Bot Becomes Group Admin !`,
    OnlyOwner: `\`[ # ]\` This Command Can Only Be Used By Owner !`,
    OnlyGrup: `\`[ # ]\` This Command Can Only Be Used In Group Chat !`,
    private: `\`[ # ]\` This Command Can Only Be Used In Private Chat !`,
    wait: `\`[ # ]\` Wait Wait a minute`,
    notregist: `\`[ # ]\` You are not registered in the Bot Database. Please register first.`,
    premium: `\`[ # ]\` Premium only" Want Premium? Chat Owner`,
}


// Batas Setting
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})